A brand-new feature in BIAS FX2 that fully utilizes our pedalboard style presets is the **Scene** mode.

When scene mode is entered, you have 4 scene slots to use: you can turn on/off the effects/amps on the signal path and save it as a scene to quickly toggle and switch from different scenarios in a song.

For example, you can use a clean setting in your intro, turn on a distortion pedal when going into the chorus, and turn on boost and delay for your solo. You can set them as different scenes in the same preset and switch very quickly just as if you’re using a physical pedalboard.  Everything you changed in scene mode will be automatically saved.

[[text in layer 3 b]]
[[text in layer 2 b]]
[[4]]
![Screen_Shot_2020-10-20_at_1.48.06_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244332/Screen_Shot_2020-10-20_at_1.48.06_PM.png)