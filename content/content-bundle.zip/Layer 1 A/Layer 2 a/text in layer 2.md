**What is Rewind?**

-   The Rewind features is essentially a background recorder that captures your playing without you actively engaging it.
-   If you accidentally come across a musical idea that you like, and want to go back and listen to the idea again, Rewind allows you to do exactly that.  
      
    

**How does it work?**

-   For the first time (since updating the application), you need to turn on Rewind manually (in the menu).
-   Once turned on, Rewind will always be on until you turn it off (even the next time you launch the program).
-   If Rewind is activated, you can see its icon slowly blinking on the top bar.  
      
    ![Screen_Shot_2022-09-13_at_3.45.39_PM.png](https://help.positivegrid.com/hc/article_attachments/9124352400525/Screen_Shot_2022-09-13_at_3.45.39_PM.png)  
      
    

**How to use Rewind?**

[[4]]
[[text in layer 2 c]]

-   Click on Rewind’s icon to open its function tab.
-   Info of the past recording will be shown.  
      
    ![mceclip0.png](https://help.positivegrid.com/hc/article_attachments/9124353798669/mceclip0.png)