**1. Add / remove effects**

You can click “Add” in the middle of the window to open the effects menu.  Double-click on the desired effect or drag the guitar effect anywhere on the signal path to add. Place the mouse cursor over the effect and click “x” to remove the effect.

![Screen_Shot_2020-10-20_at_1.38.17_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244132/Screen_Shot_2020-10-20_at_1.38.17_PM.png)

**2. Replace, engage and bypass amps and effects**

You can click the green button when the cursor is over an effect or amp to engage/bypass it, or you can click the led light on the control panel to do the same. Double-clicking any item on the signal path will open the item menu to replace the target amp or effect.

![Screen_Shot_2020-10-20_at_1.39.26_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244232/Screen_Shot_2020-10-20_at_1.39.26_PM.png)

[[text in layer 3 Demo]]