# **Signal Path Management**

## **1. Add / remove effects**

You can click “Add” in the middle of the window to open the effects menu.  Double-click on the desired effect or drag the guitar effect to anywhere on the signal path to add. Place the mouse cursor over the effect and click “x” to remove the effect.

![Screen_Shot_2020-10-20_at_1.38.17_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244132/Screen_Shot_2020-10-20_at_1.38.17_PM.png)

### **2. Replace, engage and bypass amps and effects**

You can click the green button when the cursor is over an effect or amp to engage/bypass it, or you can click the led light on the control panel to do the same. Double-clicking any item on the signal path will open the item menu to replace the target amp or effect.

![Screen_Shot_2020-10-20_at_1.39.26_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244232/Screen_Shot_2020-10-20_at_1.39.26_PM.png)

#### **3. Drag and drop items on signal path**

If you want to change the sequence of the signal path, just drag and drop any effect to the place you want. When in dual path mode, dragging the item to the middle of 2 paths lets you drop it into the “middle FX”, in case you want to run the same setting in both paths in the FX loop position.

![Screen_Shot_2020-10-20_at_1.42.59_PM.png](https://help.positivegrid.com/hc/article_attachments/360073498831/Screen_Shot_2020-10-20_at_1.42.59_PM.png)

**4. Single/dual path**

You can click on single/dual to set up a single or dual signal path, if you run a dual signal path routing, it will automatically add a splitter and a mixer in the front and back of the amps. You can select each path’s volume/pan/delay in the mixer, and how the signal is split in the splitter.  Please notice that if you want to add delay in the mixer, please pan the 2 paths to L and R in case of phasing issues in your overall sound.

![](https://lh6.googleusercontent.com/cUnTcBbIhDzwMyE04r6a9WrP_Cl0BIU9dr1jRaPT-6_gwuk8_GXdWQRPozr15ikOkQTma9Mq3J3sB-CgJNh2mxvWJtvSWS5Z2qmgTm5PrKY8AWwAeSGSWntK2Z89tX55pbuHJp-J)

5. Clear / undo / redo

When you want to make a whole new preset, just click Clear and you’ll have a clean signal path with only a noise gate and an amp. You can also click undo/redo when editing signal path routing.

![](https://lh4.googleusercontent.com/cBhT4UyLXMqNU2uWg1uOpt7qZ8pu2OmBdzv2MVU3l_4kEMqEwFyMpQrO-Y7-yKApziOm-Hz9j7Q2oElMS01LJ4MCuVwsq2YsX1yKOE_V-eFIVoKwlA2PGYHF0p0HrmOAnj1dC2Ss)

**6. Cabs and IR Loader**

In the Cab module, you can click the cab model bar to select different cab models or choose between Celestion cabinets or IR loaders. BIAS FX 2 provides 3 Celestion official mix IR files as the factory default, and you can import yours as well.

_*IR Loader currently supports only .wav files in 44.1 / 48 / 88.2 / 96 kHz, 16bit / 24bit format, with maximum length of 500ms._

_![Screen_Shot_2020-10-20_at_1.46.52_PM.png](https://help.positivegrid.com/hc/article_attachments/360073498851/Screen_Shot_2020-10-20_at_1.46.52_PM.png)_

![Screen_Shot_2020-10-20_at_1.47.19_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244312/Screen_Shot_2020-10-20_at_1.47.19_PM.png)

**7. Scene mode**

A brand new feature in BIAS FX2 that fully utilizes our pedalboard style presets is the  Scene mode. When scene mode is entered, you have 4 scene slots to use: you can turn on/off the effects/amps on the signal path and save it as a scene to quickly toggle and switch from different scenarios in a song. For example, you can use a clean setting in your intro, turn on a distortion pedal when going into the chorus, and turn on boost and delay for your solo. You can set them as different scenes in the same preset and switch very quickly just as if you’re using a physical pedalboard.  Everything you changed in scene mode will be automatically saved.

![Screen_Shot_2020-10-20_at_1.48.06_PM.png](https://help.positivegrid.com/hc/article_attachments/360073244332/Screen_Shot_2020-10-20_at_1.48.06_PM.png)

#### **Preset Management**

**1. Browsing presets**

![Screen_Shot_2020-10-20_at_1.49.58_PM.png](https://help.positivegrid.com/hc/article_attachments/360073498911/Screen_Shot_2020-10-20_at_1.49.58_PM.png)

To the left of the top bar is the preset display bar. It shows the current bank name and preset name, and you can use the left and right arrow to quickly browse through previous / next presets. The preset save menu gives you options to overwrite preset / save as a new preset or share this preset to the ToneCloud.

You can click the preset bar to enter preset browsing mode.  In the traditional view, you can view by different banks and presets, you can choose from different preset sorting methods, or search directly by name.  If you click the star in front of the preset it will be stored in the favorites bank where you can find your favorite presets very easily.

![Screen_Shot_2022-01-05_at_10.14.08_AM.png](https://help.positivegrid.com/hc/article_attachments/4418696935565/Screen_Shot_2022-01-05_at_10.14.08_AM.png)

You can also use spread view to manage all banks and presets. You can simply drag and drop to copy or move presets to the target bank which makes managing presets during different gigs extremely easy. You should try this now!

**![Screen_Shot_2022-01-05_at_10.19.05_AM.png](https://help.positivegrid.com/hc/article_attachments/4418705947149/Screen_Shot_2022-01-05_at_10.19.05_AM.png)**

**2. Editing Banks / Presets**

When you place your mouse cursor on a bank or preset, it will display the edit and delete buttons for you to delete the bank/preset or change the name of the bank/preset. Please note that you can’t delete factory banks/presets.

![](https://lh3.googleusercontent.com/7xA16Ycxq5xcTWzmMzxtOx7985qq-Y3Ytdo3EVOqSP-9ZZHSo1Vnmeo7-FFMYQ9HgQu8n3Ftp0giS2x3VbtPxO3mw1ziFJAw7TbBycXwpnSOGuYQLyzbytY13YE6hQW3XshpKETH)  

#### **Guitar Match**

**1. Match source guitar**

**![](https://lh3.googleusercontent.com/1w5X_trlCDFNVyT2z_MKzHgdLUvRuRjM37OeN4GvQ4MMVdwZVyokHhD2tbqi_Y_NQiz_qcTJlQnK9_ZpmGVGCVsmspAbdQuTESBTLOBVedIbSoxymdVR08DWS3DqwOG_211jJbGf)**

The entry point of the Guitar Match is to the middle left of the bottom bar.  This is the first stop of the signal flow in shaping your guitar input and matching it to another guitar’s sound characters. If you want to engage this module, please remember to turn the flip switch to “ON”.

The first step is to match your instrument. Please select your body shape to create a match page (you can refer to the graphic to see which type your instrument is).  Here we take an LP style guitar as an example:

![mceclip1.png](https://help.positivegrid.com/hc/article_attachments/360073498951/mceclip1.png)

Then select the correct pickup configuration according to your instrument:

![mceclip2.png](https://help.positivegrid.com/hc/article_attachments/360073244472/mceclip2.png)

And choose a pickup position to begin the matching process.

  
When measuring your pickup output, please turn your volume on your guitar to maximum, and play several notes using your usual single note articulation until it shows “Complete”

**![mceclip3.png](https://help.positivegrid.com/hc/article_attachments/360073244512/mceclip3.png)**

_If you're encountered with the 'No Signal' message, please go to the Audio Setting tab and make sure the Input is set to 'Mono', not 'Stereo._

![mceclip6.png](https://help.positivegrid.com/hc/article_attachments/360073248172/mceclip6.png)

In the matching step, please follow the instructions on screen. Play an arpeggio in different positions on your guitar. If your input is successful, you’ll see the dot of each string become solid. Repeat the process from open position to the 12th fret and the matching step will be finished.

**![mceclip7.png](https://help.positivegrid.com/hc/article_attachments/360073248192/mceclip7.png)**

**2. Select target guitar**

**![](https://lh4.googleusercontent.com/z7tM9IMvR-jXBiz7S1lL4I_0bHTnMJN7YHqGC5cmuchEWFKuO6jVUJ7Q_IItVuFxlSRIHl5uNLXZK7gtJ7F_SUe3hMOe_salsdeYLYCHt4Il5dH7LUgdrjTI0AxRBw2myPHi7GM_)**

After successfully matching your instrument, you can match another pickup position, or go to target guitar page.  On this page, you can select up to 18 different boutique guitars (Elite license) to choose from, and you can adjust some details to suit your personal preferences. Please find the full list of all the target guitar specs we provide in this link: [Guitar Match List](https://help.positivegrid.com/hc/en-us/articles/360025480871-Guitar-Match-List).

#### **ToneCloud**

**1. Download / preview / like / comment on a preset**

![mceclip8.png](https://help.positivegrid.com/hc/article_attachments/360073248232/mceclip8.png)

You can click the icon to the left of the top bar to access ToneCloud. You’ll see thousands of presets on the cloud: In each block, you can click icons for corresponding actions such as download/preview / more details/comment / like. If you would like to download a preset, please remember to log in to your ToneCloud account first.

If you only want to see the presets downloadable for your FX2 license tier, please go to the Settings (the little gear icon) on the ToneCloud and choose "Available download only"

![mceclip9.png](https://help.positivegrid.com/hc/article_attachments/360073503631/mceclip9.png)

When in preview mode, you can temporarily play through the selected preset to see if you like the sound of it.

**![mceclip4.png](https://help.positivegrid.com/hc/article_attachments/360073244612/mceclip4.png)**

**2. Search / sort / multiple download**

On the top left is the search bar, where you can search by preset title/description, and sort all the presets by upload time or popularity. In BIAS FX2, you are also able to download multiple presets at once: just click the “multiple download” button on the top right and select all the presets you want to download.

![](https://lh4.googleusercontent.com/dQsECubgC4774XZTDPiLZnD9UYnWSBabc1QVYRMiehY0X4rOzCKxbVNzDRmIhUyf_afay-1cWjDYongr2ZF3t6VKxpKPygH4L5aRD8VK2d6pUouOe4gg2K4LL6tgXFqzvgg4e8QJ)