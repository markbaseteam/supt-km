In the Cab module, you can click the cab model bar to select different cab models or choose between Celestion cabinets or IR loaders.

_![Screen_Shot_2020-10-20_at_1.46.52_PM.png](https://help.positivegrid.com/hc/article_attachments/360073498851/Screen_Shot_2020-10-20_at_1.46.52_PM.png)_

**Using [Celestion Classic Pack & Celestion Modern Vintage Pack](https://www.positivegrid.com/search?q=celestion)**

[Tutorial Video](https://youtu.be/IpawvQT_sRs)

1. Click cab and click "Cab Model".
[[4]]
[[3]]
[[text in layer 2 c]]
![Screen_Shot_2021-06-10_at_16.44.50.png](https://help.positivegrid.com/hc/article_attachments/4402766312973/Screen_Shot_2021-06-10_at_16.44.50.png)